import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import LoginScreen from '../screens/LoginScreen';
import TableSelect from '../screens/TableSelect';
import WaiterScreen from '../screens/WaiterScreen';
import KitchenScreen from '../screens/KitchenScreen';

const Stack = createStackNavigator();

export default function MainRouter(){
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login" screenOptions={{headerShown:false}}>
        <Stack.Screen name="Login" component={LoginScreen} />
        <Stack.Screen name="TableSelect" component={TableSelect} />
        <Stack.Screen name="Waiter" component={WaiterScreen} />
        <Stack.Screen name="Kitchen" component={KitchenScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
