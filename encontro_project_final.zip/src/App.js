import React from 'react';
import MainRouter from './navigation/MainRouter';
import { AppProvider } from './context/AppContext';

export default function App(){
  return (
    <AppProvider>
      <MainRouter />
    </AppProvider>
  );
}
