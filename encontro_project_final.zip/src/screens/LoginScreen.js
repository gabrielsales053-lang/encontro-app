import React, { useState, useContext } from 'react';
import { View, Text, TextInput, TouchableOpacity } from 'react-native';
import { AppContext } from '../context/AppContext';

export default function LoginScreen({ navigation }){
  const [pin, setPin] = useState('');
  const { validatePin } = useContext(AppContext);

  const submit = () => {
    if(validatePin(pin)) navigation.replace('TableSelect');
    else alert('PIN incorreto');
  };

  return (
    <View style={{flex:1,backgroundColor:'#1b120c',justifyContent:'center',padding:20}}>
      <Text style={{color:'#f7d08a',fontSize:28,textAlign:'center',marginBottom:12}}>Bem-vindo! 😊</Text>
      <TextInput secureTextEntry keyboardType="numeric" maxLength={4}
        onChangeText={setPin} value={pin}
        style={{marginTop:6,backgroundColor:'#3b2a1f',color:'#fff',padding:16,borderRadius:12,fontSize:22,textAlign:'center'}}/>
      <TouchableOpacity onPress={submit} style={{backgroundColor:'#f0c46a',padding:12,borderRadius:10,marginTop:16}}>
        <Text style={{textAlign:'center',fontWeight:'700'}}>Entrar</Text>
      </TouchableOpacity>
    </View>
  );
}
