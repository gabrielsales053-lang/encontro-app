import React, { useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, TextInput, Button } from 'react-native';
import DB from '../services/db';
import PrinterService from '../services/printer';

export default function WaiterScreen({ route, navigation }){
  const { table } = route.params;
  const categories = ['Salgados','Lanches','Pastéis','Porções','Bebidas','Sucos','Drinks','Milk-shake'];
  const menu = {
    'Salgados': [{id:'s1',name:'Coxinha',price:6}],
    'Lanches': [{id:'x1',name:'X-Burger',price:18},{id:'x2',name:'X-Salada',price:20}],
    'Pastéis': [{id:'p1',name:'Pastel Carne',price:9}],
    'Porções': [{id:'po1',name:'Batata Frita',price:15}],
    'Bebidas': [{id:'b1',name:'Coca-Cola Lata',price:6}],
    'Sucos': [{id:'su1',name:'Suco Laranja',price:10}],
    'Drinks': [{id:'d1',name:'Caipirinha',price:15}],
    'Milk-shake': [{id:'m1',name:'Milk-shake Chocolate',price:14}]
  };

  const [cat, setCat] = useState(categories[0]);
  const [selected, setSelected] = useState([]);
  const [obs, setObs] = useState('');

  const toggleItem = (it) => setSelected(s => [...s, it]);

  const submit = async () => {
    if(selected.length===0) return;
    const newOrder = {
      order_id: `O${Date.now()}`,
      table,
      items: selected,
      obs,
      status:'recebido',
      origin:'garcom',
      created_at: new Date().toISOString(),
      sent_to_kitchen:0
    };
    await DB.saveOrder(newOrder);
    try{
      await PrinterService.printOrder(newOrder,{copies:2});
    }catch(e){
      console.warn('print failed',e);
    }
    navigation.replace('Kitchen');
  };

  return (
    <View style={{flex:1, backgroundColor:'#1b120c', padding:12}}>
      <Text style={{color:'#f7d08a',fontWeight:'700',marginBottom:8}}>Mesa: {table}</Text>
      <FlatList horizontal data={categories} keyExtractor={i=>i} renderItem={({item})=>(
        <TouchableOpacity onPress={()=>setCat(item)} style={{padding:8,margin:6, backgroundColor:'#3b2a1f', borderRadius:8}}>
          <Text style={{color:'#fff'}}>{item}</Text>
        </TouchableOpacity>
      )} />
      <FlatList data={menu[cat]} keyExtractor={i=>i.id} renderItem={({item})=>(
        <TouchableOpacity onPress={()=>toggleItem(item)} style={{padding:10,backgroundColor:'#33221a',marginVertical:6,borderRadius:8}}>
          <Text style={{color:'#fff'}}>{item.name} - R${item.price}</Text>
        </TouchableOpacity>
      )} />
      <TextInput placeholder="Observação" onChangeText={setObs} value={obs} style={{backgroundColor:'#fff',borderRadius:8,padding:8,marginTop:8}}/>
      <Button title="Enviar para Cozinha" onPress={submit} />
    </View>
  );
}
