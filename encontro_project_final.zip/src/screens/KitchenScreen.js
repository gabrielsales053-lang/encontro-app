import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';
import DB from '../services/db';
import Sound from 'react-native-sound';

export default function KitchenScreen(){
  const [orders, setOrders] = useState([]);

  useEffect(()=>{
    const load = async ()=>{
      const list = await DB.listPending();
      setOrders(list);
    };
    load();
    const t = setInterval(load,5000);
    return ()=>clearInterval(t);
  },[]);

  useEffect(()=>{
    if(orders.length>0){
      const s = new Sound('order-dingdong.wav', Sound.MAIN_BUNDLE, (e)=>{ if(!e) s.play(); });
    }
  },[orders]);

  const markDone = async (order) => {
    await DB.updateStatus(order.order_id,'pronto');
    const list = await DB.listPending();
    setOrders(list);
  };

  return (
    <View style={{flex:1,backgroundColor:'#1b120c',padding:12}}>
      <Text style={{color:'#f7d08a',fontSize:20,fontWeight:'700',marginBottom:8}}>📋 Pedidos - Cozinha</Text>
      <ScrollView>
        {orders.map(o=> (
          <View key={o.order_id} style={{backgroundColor:'#3b2a1f',padding:10,borderRadius:8,marginBottom:10}}>
            <Text style={{color:'#fff',fontWeight:'700'}}>Pedido {o.order_id} — {o.table}</Text>
            <Text style={{color:'#fff'}}>{o.items.map(i=>i.name).join(', ')}</Text>
            <TouchableOpacity onPress={()=>markDone(o)} style={{marginTop:8,backgroundColor:'#f0c46a',padding:8,borderRadius:6}}>
              <Text>Marcar como Pronto</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </View>
  );
}
