import React from 'react';
import { View, Text, ScrollView, TouchableOpacity } from 'react-native';

export default function TableSelect({ navigation }){
  const tables = Array.from({length:10}, (_,i)=>`Mesa ${String(i+1).padStart(2,'0')}`).concat(['Balcão','Delivery']);
  return (
    <View style={{flex:1,backgroundColor:'#1b120c',padding:20}}>
      <Text style={{color:'#f7d08a',fontSize:22,marginBottom:12}}>Escolha a Mesa</Text>
      <ScrollView>
        {tables.map(t=>(
          <TouchableOpacity key={t} onPress={()=>navigation.replace('Waiter',{table:t})} style={{backgroundColor:'#3b2a1f',padding:14,borderRadius:10,marginBottom:10}}>
            <Text style={{color:'#fff',fontWeight:'700'}}>{t}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}
