import TcpSocket from 'react-native-tcp-socket';
import { BluetoothEscposPrinter } from 'react-native-bluetooth-escpos-printer';

const format58mm = (order) => {
  const lines = [];
  lines.push('LANCHONETE ENCONTRO NA ESQUINA\n');
  lines.push(`${order.table} | ${order.order_id}\n`);
  lines.push('-------------------------------\n');
  order.items.forEach(i=> lines.push(`${i.name} - R$${i.price || ''}\n`));
  if(order.obs) lines.push('OBS: ' + order.obs + '\n');
  lines.push('\n\n');
  return Buffer.from(lines.join(''), 'utf8');
};

const printViaTCP = (ip, port, buf) => new Promise((res,rej)=>{
  const client = TcpSocket.createConnection({ port: port||9100, host: ip }, () => {
    client.write(buf);
    client.destroy();
    res();
  });
  client.on('error', e=>rej(e));
});

const printOrder = async (order, opts={}) => {
  const cfg = { type:'wifi', ip:'192.168.0.100', port:9100 };
  const buf = format58mm(order);
  if(cfg.type === 'wifi' && cfg.ip){
    try{ await printViaTCP(cfg.ip, cfg.port, buf); return; }catch(e){ console.warn('wifi print fail',e); }
  }
  try{
    await BluetoothEscposPrinter.printText('LANCHONETE ENCONTRO NA ESQUINA\n', {});
    await BluetoothEscposPrinter.printText(`${order.table} | ${order.order_id}\n`, {});
    for(const it of order.items){
      await BluetoothEscposPrinter.printText(`${it.name}\n`, {});
    }
    await BluetoothEscposPrinter.printText('\n\n\n', {});
  }catch(e){ console.warn('bt print fail', e); throw e; }
};

export default { printOrder };
