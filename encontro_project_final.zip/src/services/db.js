import SQLite from 'react-native-sqlite-storage';
const db = SQLite.openDatabase({name:'encontro.db',location:'default'});

const init = () => {
  db.transaction(tx=>{
    tx.executeSql(`CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id TEXT,
      table_name TEXT,
      items TEXT,
      obs TEXT,
      status TEXT,
      origin TEXT,
      created_at TEXT,
      sent_to_kitchen INTEGER
    )`);
  });
};

const saveOrder = (order) => new Promise((res,rej)=>{
  db.transaction(tx=>{
    tx.executeSql('INSERT INTO orders (order_id,table_name,items,obs,status,origin,created_at,sent_to_kitchen) VALUES (?,?,?,?,?,?,?,?)',
      [order.order_id, order.table, JSON.stringify(order.items), order.obs, order.status, order.origin, order.created_at, order.sent_to_kitchen],
      (_,r)=>res(r), (_,e)=>rej(e)
    );
  });
});

const listPending = () => new Promise((res,rej)=>{
  db.transaction(tx=>{
    tx.executeSql('SELECT * FROM orders WHERE status <> ? ORDER BY id DESC', ['entregue'], (_, { rows })=>{
      const out = [];
      for(let i=0;i<rows.length;i++){
        const r = rows.item(i);
        out.push({ ...r, items: JSON.parse(r.items) });
      }
      res(out);
    }, (_,e)=>rej(e));
  });
});

const updateStatus = (order_id, status) => new Promise((res,rej)=>{
  db.transaction(tx=>{
    tx.executeSql('UPDATE orders SET status=? WHERE order_id=?', [status, order_id], (_,r)=>res(r), (_,e)=>rej(e));
  });
});

export default { init, saveOrder, listPending, updateStatus };
