#!/usr/bin/env bash
set -e
echo "Run this inside Termux proot-debian with Android SDK and JDK configured"

yarn install
cd android
./gradlew assembleRelease
