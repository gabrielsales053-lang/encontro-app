See previous instructions provided in chat for Termux and PC build steps.

