# Encontro na Esquina - Projeto para build

Siga as instruções em README_build.md for building.