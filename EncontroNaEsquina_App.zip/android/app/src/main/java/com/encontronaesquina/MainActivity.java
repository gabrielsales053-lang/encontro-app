package com.encontronaesquina;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    Button btn = findViewById(R.id.btnPedido);
    TextView status = findViewById(R.id.status);

    btn.setOnClickListener(v -> {
      status.setText("✅ Pedido enviado com sucesso!");
      // Aqui, nas próximas versões, ativaremos a impressão (58mm – Wi-Fi/Bluetooth).
    });
  }
}
